exports.foo = function () {
    return require('b');
};

var interface_c_p_base_platform_string =
[
    [ "bootstrap", "interface_c_p_base_platform_string.html#a33792139ce4da58bf85ef83b9cdd1336", null ],
    [ "sizeOfString:withFont:forWidth:", "interface_c_p_base_platform_string.html#aa9dc7967e479fb219a5bfdd61c0942f6", null ]
];
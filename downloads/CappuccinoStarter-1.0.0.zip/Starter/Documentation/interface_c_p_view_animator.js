var interface_c_p_view_animator =
[
    [ "addAnimations:forAction:", "interface_c_p_view_animator.html#ad666b9143a9e86613276f214d65e7f70", null ],
    [ "addFrameUpdaters:forAction:", "interface_c_p_view_animator.html#a748192213de0f60bf2ed1854804c345f", null ],
    [ "initWithTarget:", "interface_c_p_view_animator.html#aeb80bcb0f1c9c970223e5f17e7af2b54", null ],
    [ "needsPeriodicFrameUpdatesForKeyPath:", "interface_c_p_view_animator.html#aacfbb3d36408992dab142b6064203641", null ],
    [ "removeFromSuperview", "interface_c_p_view_animator.html#aaa48f6ec7ad24f800d8cdbe161e3fd5e", null ],
    [ "setAlphaValue:", "interface_c_p_view_animator.html#aac22a6480ae1a4b0fc9786a63890d7d7", null ],
    [ "setBackgroundColor:", "interface_c_p_view_animator.html#a6dabca7d9c6d8e9fc261d2af3205019d", null ],
    [ "setFrame:", "interface_c_p_view_animator.html#a6b4db8c451a964ca422516d1d58a9d53", null ],
    [ "setFrameOrigin:", "interface_c_p_view_animator.html#ab082b2f93e18538a11d514ac7387a731", null ],
    [ "setFrameSize:", "interface_c_p_view_animator.html#a45118a302e27a1bf555badf489c96b2f", null ],
    [ "setHidden:", "interface_c_p_view_animator.html#a07f175038375181bdacd8052cc96c49e", null ],
    [ "setWantsPeriodicFrameUpdates:", "interface_c_p_view_animator.html#a9b4173ff6a8e637dd843acea0285f4c5", null ],
    [ "stopUpdaterWithIdentifier:", "interface_c_p_view_animator.html#a94aeb857cdec7699a7e5bdab50049c09", null ],
    [ "wantsPeriodicFrameUpdates", "interface_c_p_view_animator.html#a7c13fa93a74f6e38a35f63ee96e90c8a", null ]
];
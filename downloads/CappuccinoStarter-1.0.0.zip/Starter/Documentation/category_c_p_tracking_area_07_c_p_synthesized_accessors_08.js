var category_c_p_tracking_area_07_c_p_synthesized_accessors_08 =
[
    [ "implementedOwnerMethods", "category_c_p_tracking_area_07_c_p_synthesized_accessors_08.html#a9382d5ae0fb2f3d2ca2b869e3a4a6db6", null ],
    [ "options", "category_c_p_tracking_area_07_c_p_synthesized_accessors_08.html#aec308cdaa942b09ab98177dc6cef55a5", null ],
    [ "owner", "category_c_p_tracking_area_07_c_p_synthesized_accessors_08.html#ac80810ebfd188f3a83b2fdfa1829f30e", null ],
    [ "rect", "category_c_p_tracking_area_07_c_p_synthesized_accessors_08.html#a0d578252f7237277c823763b3fc077e1", null ],
    [ "setView:", "category_c_p_tracking_area_07_c_p_synthesized_accessors_08.html#aaae83dbe0be74e596cd6ca51b387da48", null ],
    [ "userInfo", "category_c_p_tracking_area_07_c_p_synthesized_accessors_08.html#a2155c3d86821078818b91078ab9779ed", null ],
    [ "view", "category_c_p_tracking_area_07_c_p_synthesized_accessors_08.html#a637e659467bbc1e1e5291fff15c95b20", null ],
    [ "windowRect", "category_c_p_tracking_area_07_c_p_synthesized_accessors_08.html#a007e52a80fdbdbebf892cfedca9527e6", null ]
];
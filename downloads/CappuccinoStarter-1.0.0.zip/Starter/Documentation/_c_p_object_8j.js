var _c_p_object_8j =
[
    [ "<CPCoding>", "protocol_c_p_coding-p.html", "protocol_c_p_coding-p" ],
    [ "CPDescriptionOfObject", "_c_p_object_8j.html#acd1b70220fca7c49443a74823c4c5d3d", null ],
    [ "isa", "_c_p_object_8j.html#af9af166d9c3cdac5c44e646be5d22b78", null ]
];
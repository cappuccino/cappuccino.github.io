var class_c_p_text_tab =
[
    [ "encodeWithCoder:", "class_c_p_text_tab.html#aea0252527deeb8a635875f92904fe269", null ],
    [ "initWithCoder:", "class_c_p_text_tab.html#af394f9a3a0e17bd97a94f84f45c27686", null ],
    [ "initWithType:location:", "class_c_p_text_tab.html#a14e8d8ad10872a2b13cd0caf048847bd", null ],
    [ "location", "class_c_p_text_tab.html#a4acb4597263c9513442c871cb8468f69", null ],
    [ "setLocation:", "class_c_p_text_tab.html#a14596041da3d7f880fa48bd2cece76a5", null ],
    [ "setTabStopType:", "class_c_p_text_tab.html#a04a64e4179eb9509368d02d128ec1571", null ],
    [ "tabStopType", "class_c_p_text_tab.html#a74317d6a04d57a452b79c59399ba145b", null ]
];
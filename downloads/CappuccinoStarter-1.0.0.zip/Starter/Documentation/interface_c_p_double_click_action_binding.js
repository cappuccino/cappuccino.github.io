var interface_c_p_double_click_action_binding =
[
    [ "init", "interface_c_p_double_click_action_binding.html#ac2e60075e2338fc7fb56a26c10b3090b", null ]
];
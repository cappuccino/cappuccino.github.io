var interface_c_p_user_defaults_controller =
[
    [ "appliesImmediately", "interface_c_p_user_defaults_controller.html#a287d6f37b89ae3d6ca6e21453e5dd900", null ],
    [ "defaults", "interface_c_p_user_defaults_controller.html#a92145064a691564c525ef66bb2ed40bd", null ],
    [ "encodeWithCoder:", "interface_c_p_user_defaults_controller.html#afbd91dbd6761c7a1e721e7159a699f2d", null ],
    [ "hasUnappliedChanges", "interface_c_p_user_defaults_controller.html#a93a0ba26964a6c2fabd1ab6ac4d4d996", null ],
    [ "initialValues", "interface_c_p_user_defaults_controller.html#a45c1cc2a9ec74182bf35f81f1fab9c26", null ],
    [ "initWithCoder:", "interface_c_p_user_defaults_controller.html#a75cd1fe149ce9943517188ff49fc73ae", null ],
    [ "initWithDefaults:initialValues:", "interface_c_p_user_defaults_controller.html#abb977910c56fb58a6c599c175184b880", null ],
    [ "revert:", "interface_c_p_user_defaults_controller.html#a01d9ec57c59b0cdf86feb72e12134035", null ],
    [ "revertToInitialValues:", "interface_c_p_user_defaults_controller.html#a95dba43524ca07ecb5cd2dead6ce9faa", null ],
    [ "save:", "interface_c_p_user_defaults_controller.html#a97e245782221e509130018ef651e67a3", null ],
    [ "setAppliesImmediately:", "interface_c_p_user_defaults_controller.html#ab4b3a9c155fdc1aa0c1043614565670d", null ],
    [ "setInitialValues:", "interface_c_p_user_defaults_controller.html#ac48454e3ef83fbc82a81c109fd113802", null ],
    [ "sharedUserDefaultsController", "interface_c_p_user_defaults_controller.html#a1124c3b26d1e4aa58ead1c5de7b5e658", null ],
    [ "values", "interface_c_p_user_defaults_controller.html#a35018a0e0eea188ac766f337afa41cd9", null ]
];
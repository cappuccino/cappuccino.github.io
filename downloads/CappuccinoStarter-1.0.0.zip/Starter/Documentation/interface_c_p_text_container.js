var interface_c_p_text_container =
[
    [ "containerSize", "interface_c_p_text_container.html#a6b9f08a6ac9b981425feb68f6d34383e", null ],
    [ "containsPoint:", "interface_c_p_text_container.html#a85e27ef229dd5a047e699ae802c8cacb", null ],
    [ "encodeWithCoder:", "interface_c_p_text_container.html#af6dcd69fbc3d7af1114c975e836b6568", null ],
    [ "init", "interface_c_p_text_container.html#aa17ae76d5c06a346a10b5228fc2bb008", null ],
    [ "initWithCoder:", "interface_c_p_text_container.html#a4135c5d754b7fd73c22a9d0dc02f2289", null ],
    [ "initWithContainerSize:", "interface_c_p_text_container.html#a149c120bf3382227ad29f8a0f5cad7bb", null ],
    [ "isSimpleRectangularTextContainer", "interface_c_p_text_container.html#a0cc64b15b905aa0bd9d8ca8cc529d746", null ],
    [ "layoutManager", "interface_c_p_text_container.html#a300f87abfa2cf86469807549fda4459a", null ],
    [ "lineFragmentPadding", "interface_c_p_text_container.html#a03122b6b0d15f2f96bf4130cd1adfb23", null ],
    [ "lineFragmentRectForProposedRect:sweepDirection:movementDirection:remainingRect:", "interface_c_p_text_container.html#abd70ca9c9dfbaa42620b539a504ca042", null ],
    [ "setContainerSize:", "interface_c_p_text_container.html#a2eb643095db8d384b68f27c4a7b976c5", null ],
    [ "setLayoutManager:", "interface_c_p_text_container.html#a167f840a6bc7b41995ddc412d90212f3", null ],
    [ "setLineFragmentPadding:", "interface_c_p_text_container.html#af9ecff971c8533e4ad50c52a706cc5b7", null ],
    [ "setTextView:", "interface_c_p_text_container.html#a53b554baa47195c25657e3e364344b80", null ],
    [ "setWidthTracksTextView:", "interface_c_p_text_container.html#afa3c9fc5052e587faf23fdc63ae0dfc2", null ],
    [ "textView", "interface_c_p_text_container.html#a615353f1a3d990da720586c48eb277df", null ],
    [ "textViewFrameChanged:", "interface_c_p_text_container.html#aebba2e325581d3043485bd6d20798960", null ]
];
var category_c_p_scroller_07_deprecated_08 =
[
    [ "setFloatValue:knobProportion:", "category_c_p_scroller_07_deprecated_08.html#ad0b2dd18ef37200c8e2a1f287d1b0d06", null ]
];
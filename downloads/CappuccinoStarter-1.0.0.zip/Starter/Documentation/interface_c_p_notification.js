var interface_c_p_notification =
[
    [ "init", "interface_c_p_notification.html#a22d9d1151939575f19c1c9696fa29796", null ],
    [ "initWithName:object:userInfo:", "interface_c_p_notification.html#ae82791f0df782d1ca0e8ae0ab7676fec", null ],
    [ "name", "interface_c_p_notification.html#a0ddf3837c1d325016b9c59a99247a9ef", null ],
    [ "notificationWithName:object:", "interface_c_p_notification.html#afadbd24cfe71e2ef378a0e8b8f22eca1", null ],
    [ "notificationWithName:object:userInfo:", "interface_c_p_notification.html#a85de5d79d60b13c0859bf8f1f6cda604", null ],
    [ "object", "interface_c_p_notification.html#a0a912e9648acf5e7f669aed339474158", null ],
    [ "userInfo", "interface_c_p_notification.html#a2c441e9231e4d97445571728cc4117c6", null ]
];
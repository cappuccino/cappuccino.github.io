var category_c_p_tree_node_07_c_p_synthesized_accessors_08 =
[
    [ "parentNode", "category_c_p_tree_node_07_c_p_synthesized_accessors_08.html#a11b986cec02c56477fc900e09ed483e0", null ],
    [ "representedObject", "category_c_p_tree_node_07_c_p_synthesized_accessors_08.html#a828546d9e1e4f513ca5f7614cdb9c8e0", null ]
];
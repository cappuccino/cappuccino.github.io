var category_c_p_object_controller_07_c_p_coding_08 =
[
    [ "awakeFromCib", "category_c_p_object_controller_07_c_p_coding_08.html#a27c42a14f1cb1fc110bbf6e3540b1021", null ],
    [ "encodeWithCoder:", "category_c_p_object_controller_07_c_p_coding_08.html#a9b05a9b998b0cd29a7641826aa8ab373", null ],
    [ "initWithCoder:", "category_c_p_object_controller_07_c_p_coding_08.html#a59490e178d9392c532d7a83dc9683e17", null ]
];
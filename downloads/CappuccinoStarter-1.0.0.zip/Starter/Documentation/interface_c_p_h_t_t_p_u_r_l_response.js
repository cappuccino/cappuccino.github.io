var interface_c_p_h_t_t_p_u_r_l_response =
[
    [ "allHeaderFields", "interface_c_p_h_t_t_p_u_r_l_response.html#a7a476d8d57106503334b6bd4c0fe8562", null ],
    [ "parseHTTPHeaders:", "interface_c_p_h_t_t_p_u_r_l_response.html#ac7c094ccd65269eb2c3dc29bf214fb0d", null ],
    [ "statusCode", "interface_c_p_h_t_t_p_u_r_l_response.html#a3d8d3501f5ab451a84ab78175c5e7369", null ]
];
var interface_c_p_collection_view_item =
[
    [ "collectionView", "interface_c_p_collection_view_item.html#aab8419009b605e1324d78d68cd1c9a54", null ],
    [ "copy", "interface_c_p_collection_view_item.html#a62701d1029970c50faab98f876b183c5", null ],
    [ "isSelected", "interface_c_p_collection_view_item.html#a48e1436f47c6b9880472a31e2a7364bc", null ],
    [ "setRepresentedObject:", "interface_c_p_collection_view_item.html#a5e531b308426584e710eaabda58a758f", null ],
    [ "setSelected:", "interface_c_p_collection_view_item.html#a18305548f8a965b42fc7e5556ae10a08", null ]
];
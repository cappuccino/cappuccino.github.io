var interface_c_p_delayed_perform =
[
    [ "delayedPerformWithObject:selector:argument:", "interface_c_p_delayed_perform.html#a9edf01f79cfdd971a511a3fb24e554b0", null ],
    [ "initWithObject:selector:argument:", "interface_c_p_delayed_perform.html#a856ba01d0100ff2f628003e4e13928d8", null ],
    [ "isEqualToPerform:", "interface_c_p_delayed_perform.html#a841a31dc6339b5fe562cafd7b1f31413", null ],
    [ "perform", "interface_c_p_delayed_perform.html#a7e76cd450f8972a1cc0c7be096544aec", null ]
];
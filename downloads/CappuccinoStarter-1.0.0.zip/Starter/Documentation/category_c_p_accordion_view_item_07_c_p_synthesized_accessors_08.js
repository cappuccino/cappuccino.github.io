var category_c_p_accordion_view_item_07_c_p_synthesized_accessors_08 =
[
    [ "identifier", "category_c_p_accordion_view_item_07_c_p_synthesized_accessors_08.html#ad28e737281c1b7547fa0f9e63a73e0e5", null ],
    [ "label", "category_c_p_accordion_view_item_07_c_p_synthesized_accessors_08.html#aeb92a5b4ffc70457c08e4330726840a7", null ],
    [ "setIdentifier:", "category_c_p_accordion_view_item_07_c_p_synthesized_accessors_08.html#a30610c21de89f18bce5026faf1bda46b", null ],
    [ "setLabel:", "category_c_p_accordion_view_item_07_c_p_synthesized_accessors_08.html#a77ed4b05b8e3083d57fe2d1407c0aa2f", null ],
    [ "setView:", "category_c_p_accordion_view_item_07_c_p_synthesized_accessors_08.html#a9fa2fc4e3f097ad19254c9ca51f87ea0", null ],
    [ "view", "category_c_p_accordion_view_item_07_c_p_synthesized_accessors_08.html#a2685c9c26a7a14b9e0f93b9b22eb5374", null ]
];
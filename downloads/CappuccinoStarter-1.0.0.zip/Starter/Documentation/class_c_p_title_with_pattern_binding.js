var class_c_p_title_with_pattern_binding =
[
    [ "init", "class_c_p_title_with_pattern_binding.html#a6a34aec4fb983315f3c55fe9d2288548", null ]
];
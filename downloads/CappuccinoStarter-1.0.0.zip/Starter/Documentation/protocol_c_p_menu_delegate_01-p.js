var protocol_c_p_menu_delegate_01_p =
[
    [ "menuDidClose:", "protocol_c_p_menu_delegate_01-p.html#a9a98e82254489f2a52ffbbea5776c45d", null ],
    [ "menuWillOpen:", "protocol_c_p_menu_delegate_01-p.html#a28373e5ccf637bef5d5e1a9b8ca1ee76", null ]
];
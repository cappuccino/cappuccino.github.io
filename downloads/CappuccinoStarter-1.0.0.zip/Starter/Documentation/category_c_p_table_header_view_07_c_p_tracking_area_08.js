var category_c_p_table_header_view_07_c_p_tracking_area_08 =
[
    [ "cursorUpdate:", "category_c_p_table_header_view_07_c_p_tracking_area_08.html#a3931f6c1c66035171bdabc1203fd9f53", null ],
    [ "updateTrackingAreas", "category_c_p_table_header_view_07_c_p_tracking_area_08.html#a77dbafd88e136453f7ed9a481cf3dabc", null ]
];
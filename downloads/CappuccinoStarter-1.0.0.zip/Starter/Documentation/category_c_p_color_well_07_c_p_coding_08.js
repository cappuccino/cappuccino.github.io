var category_c_p_color_well_07_c_p_coding_08 =
[
    [ "encodeWithCoder:", "category_c_p_color_well_07_c_p_coding_08.html#a6ca752d251cf8c94620aeadb0b10690b", null ],
    [ "initWithCoder:", "category_c_p_color_well_07_c_p_coding_08.html#acce855ccdb9b574d6dda3edcfee9ca29", null ]
];
var interface_c_p_dragging_info =
[
    [ "draggedImage", "interface_c_p_dragging_info.html#a3286a41058de59f4b2bb0f0d09774f33", null ],
    [ "draggedImageLocation", "interface_c_p_dragging_info.html#a4c9d5827d0e1d8e0e0965ddb62418935", null ],
    [ "draggedView", "interface_c_p_dragging_info.html#a7084ed2c8439e03ec9bdb2413bbcbb39", null ],
    [ "draggedViewLocation", "interface_c_p_dragging_info.html#a40b1c97dfc51f6a5313355b1a91b92b3", null ],
    [ "draggingDestinationWindow", "interface_c_p_dragging_info.html#a28dffad334010b5255de151cf2a69aee", null ],
    [ "draggingLocation", "interface_c_p_dragging_info.html#af8646abd94a29c234cb41ea7fa3594fd", null ],
    [ "draggingPasteboard", "interface_c_p_dragging_info.html#ac4398370e690f177c80266b8b64b5dc3", null ],
    [ "draggingSource", "interface_c_p_dragging_info.html#a5a5522abafad312d8bc6cb60c2b71656", null ]
];
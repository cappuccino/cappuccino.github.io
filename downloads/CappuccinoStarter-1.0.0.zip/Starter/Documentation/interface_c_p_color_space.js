var interface_c_p_color_space =
[
    [ "CGColorSpace", "interface_c_p_color_space.html#ae01d2f938cbe13e1f0a08e4216452b40", null ],
    [ "initWithCGColorSpace:", "interface_c_p_color_space.html#abc7328485858c03e0501786f07e11714", null ],
    [ "sRGBColorSpace", "interface_c_p_color_space.html#a3e5e0d36cf61df857d2bfaa8c23cd035", null ]
];
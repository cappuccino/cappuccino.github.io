var _c_p_visual_effect_view_8j =
[
    [ "CPVisualEffectBlendingModeBehindWindow", "_c_p_visual_effect_view_8j.html#a8289cbdeb27f162687db226f7cc8f867", null ],
    [ "CPVisualEffectMaterialAppearanceBased", "_c_p_visual_effect_view_8j.html#ae0d8a461916b35b7c3465db985abd03d", null ],
    [ "CPVisualEffectStateFollowsWindowActiveState", "_c_p_visual_effect_view_8j.html#adfcd1ffb68f768cd9a6b056ca57ed84f", null ],
    [ "CPVisualEffectBlendingModeWithinWindow", "_c_p_visual_effect_view_8j.html#a5e17dffa166e612c1d0e15e6bd342a56", null ],
    [ "CPVisualEffectMaterialDark", "_c_p_visual_effect_view_8j.html#a79622b422afd2b39b64095f55ddcd3ad", null ],
    [ "CPVisualEffectMaterialLight", "_c_p_visual_effect_view_8j.html#afaafd0ecdedf82de7a0143dd48ebfa48", null ],
    [ "CPVisualEffectMaterialTitlebar", "_c_p_visual_effect_view_8j.html#ace578eab92ec38a7b4cb7f8f622f9c50", null ],
    [ "CPVisualEffectStateActive", "_c_p_visual_effect_view_8j.html#a215000fd129df17b7ac702eb46a5015e", null ],
    [ "CPVisualEffectStateInactive", "_c_p_visual_effect_view_8j.html#abe2da5eb2f9a5d183b2fbd46775b6599", null ]
];
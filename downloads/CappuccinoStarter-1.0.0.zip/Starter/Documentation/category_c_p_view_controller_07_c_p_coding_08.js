var category_c_p_view_controller_07_c_p_coding_08 =
[
    [ "encodeWithCoder:", "category_c_p_view_controller_07_c_p_coding_08.html#a569858caec69b477f55f00caef8d53eb", null ],
    [ "initWithCoder:", "category_c_p_view_controller_07_c_p_coding_08.html#a04c4560ffff7937cdbee08939c03f8ce", null ]
];
var category_c_p_view_07_core_animation_additions_08 =
[
    [ "layer", "category_c_p_view_07_core_animation_additions_08.html#a8002d7dae7b3ebf426a16ad2e1ce3f66", null ],
    [ "setLayer:", "category_c_p_view_07_core_animation_additions_08.html#a5dcd9ad462a3ef04899bbd7e7c27194b", null ],
    [ "setWantsLayer:", "category_c_p_view_07_core_animation_additions_08.html#a464c4fc13cf88e946e7f6633d31a69d1", null ],
    [ "wantsLayer", "category_c_p_view_07_core_animation_additions_08.html#af5e18257a21ca9fa95ccc3ac947f2757", null ]
];
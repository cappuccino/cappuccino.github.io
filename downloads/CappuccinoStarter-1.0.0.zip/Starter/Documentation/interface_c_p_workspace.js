var interface_c_p_workspace =
[
    [ "openFile:", "interface_c_p_workspace.html#ae9108aa3f03bfae62e5dd2ec6ebac384", null ],
    [ "openURL:", "interface_c_p_workspace.html#a3d95e04f3190f55ce6516f82af3e782a", null ],
    [ "sharedWorkspace", "interface_c_p_workspace.html#a32dc1ced59dbb6ec7e99d66e1345b0cc", null ]
];
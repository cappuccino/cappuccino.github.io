var interface_c_p_user_notification_center =
[
    [ "defaultUserNotificationCenter", "interface_c_p_user_notification_center.html#ac4031720df674cc64670a636646f0eed", null ],
    [ "deliveredNotifications", "interface_c_p_user_notification_center.html#a5db40f52904bbe4ed2b1b1de03a2da1a", null ],
    [ "deliverNotification:", "interface_c_p_user_notification_center.html#ab85505e5ac7951d3ccdb145d2e05f03d", null ],
    [ "init", "interface_c_p_user_notification_center.html#a8f2030ffb6285daf63c684a6fe1d739f", null ],
    [ "removeAllDeliveredNotifications", "interface_c_p_user_notification_center.html#a5cc60e39ffc23097f6ff07e986f9cca5", null ],
    [ "removeDeliveredNotification:", "interface_c_p_user_notification_center.html#ae0cca7f7026bc4134d873dbe35bf7116", null ],
    [ "removeScheduledNotification:", "interface_c_p_user_notification_center.html#aaa0aa911e859fb10b96ccfdcccbf7df5", null ],
    [ "scheduledNotifications", "interface_c_p_user_notification_center.html#a7d854cdf2af55c4ca14a94338cc6f429", null ],
    [ "scheduleNotification:", "interface_c_p_user_notification_center.html#aa7adfbab61f67b380212816a209f5559", null ],
    [ "setDelegate:", "interface_c_p_user_notification_center.html#aa419efe42fe732f966b4f534b9ba32bd", null ],
    [ "setDeliveredNotifications:", "interface_c_p_user_notification_center.html#a4c2e04ad8b2c8e610f1955ac847f9a5f", null ],
    [ "setScheduledNotifications:", "interface_c_p_user_notification_center.html#abfbfd9dee1935fd1c3ed37b7ad4e6186", null ]
];
var interface_c_p_platform_string =
[
    [ "metricsOfFont:", "interface_c_p_platform_string.html#a8fc6635d580ec38a1b163002b83dfe6e", null ],
    [ "sizeOfString:withFont:forWidth:", "interface_c_p_platform_string.html#a52362c6e38a0cc9e16bfe3982f3fd736", null ]
];
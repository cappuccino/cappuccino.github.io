var category_c_p_table_content_binder_07_c_p_synthesized_accessors_08 =
[
    [ "content", "category_c_p_table_content_binder_07_c_p_synthesized_accessors_08.html#a440316d980953dc9a896bef7b30bb530", null ],
    [ "setContent:", "category_c_p_table_content_binder_07_c_p_synthesized_accessors_08.html#a402e8c42ee79c51d7d6136efe1f8f206", null ]
];
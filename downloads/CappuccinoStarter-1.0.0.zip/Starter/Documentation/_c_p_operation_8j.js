var _c_p_operation_8j =
[
    [ "CPOperationQueuePriorityHigh", "_c_p_operation_8j.html#a981621b1bbdd4c385c787b2a7a27516b", null ],
    [ "CPOperationQueuePriorityLow", "_c_p_operation_8j.html#a4ad5dc97582869bd0e1f3d5bf10ab3c0", null ],
    [ "CPOperationQueuePriorityNormal", "_c_p_operation_8j.html#a36ee93cb8aee90db5cd71ecd381d0008", null ],
    [ "CPOperationQueuePriorityVeryHigh", "_c_p_operation_8j.html#a0199d107991e714a8047074f7bc0ddf2", null ],
    [ "CPOperationQueuePriorityVeryLow", "_c_p_operation_8j.html#a2feb8e1f22d3765b22ff65efe61856be", null ]
];
var category_c_p_table_column_07_n_s_in_compatibility_08 =
[
    [ "dataCell", "category_c_p_table_column_07_n_s_in_compatibility_08.html#ab2a7245e2eba99ee0a2c02b13a203f22", null ],
    [ "dataCellForRow:", "category_c_p_table_column_07_n_s_in_compatibility_08.html#ae49ee2676931bb51f7362344b04a681f", null ],
    [ "headerCell", "category_c_p_table_column_07_n_s_in_compatibility_08.html#a79495f208393c56d117eafb90353c54a", null ],
    [ "setDataCell:", "category_c_p_table_column_07_n_s_in_compatibility_08.html#a98d356b163b453c3c4c2922df536e7e2", null ],
    [ "setHeaderCell:", "category_c_p_table_column_07_n_s_in_compatibility_08.html#a050f1ff999cf660ac505a6dd0ce13efc", null ]
];
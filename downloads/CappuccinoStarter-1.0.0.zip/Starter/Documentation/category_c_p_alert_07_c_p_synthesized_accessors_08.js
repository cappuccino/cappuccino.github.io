var category_c_p_alert_07_c_p_synthesized_accessors_08 =
[
    [ "accessoryView", "category_c_p_alert_07_c_p_synthesized_accessors_08.html#a859d17fe81d0ea92ee528a4889d314e4", null ],
    [ "alertStyle", "category_c_p_alert_07_c_p_synthesized_accessors_08.html#a299d24b3592ff1bfd8ceb13dc94b3c4a", null ],
    [ "buttons", "category_c_p_alert_07_c_p_synthesized_accessors_08.html#a7a3c68f993fb9c4762c0a1c644c05632", null ],
    [ "didEndSelector", "category_c_p_alert_07_c_p_synthesized_accessors_08.html#a4e0a3c058e2a0a830cfacb765221e8bd", null ],
    [ "icon", "category_c_p_alert_07_c_p_synthesized_accessors_08.html#a4403bd3a0c0782c054a0be7c2b2e3431", null ],
    [ "setAccessoryView:", "category_c_p_alert_07_c_p_synthesized_accessors_08.html#a57e3d3e4a9540232d510d6f7c3610b8d", null ],
    [ "setAlertStyle:", "category_c_p_alert_07_c_p_synthesized_accessors_08.html#abf9aa2df1fc0a048a9dfdf74af16f3e0", null ],
    [ "setDidEndSelector:", "category_c_p_alert_07_c_p_synthesized_accessors_08.html#accc21fae32014c2b73005d18ff0cee75", null ],
    [ "setIcon:", "category_c_p_alert_07_c_p_synthesized_accessors_08.html#a27e8d9703770979fe28582e7cb3bf5e0", null ],
    [ "setShowsHelp:", "category_c_p_alert_07_c_p_synthesized_accessors_08.html#aa1a851b915aac59b678178fb90aac802", null ],
    [ "setShowsSuppressionButton:", "category_c_p_alert_07_c_p_synthesized_accessors_08.html#aedf13b6903912b33de26bc67c7894b3d", null ],
    [ "setTitle:", "category_c_p_alert_07_c_p_synthesized_accessors_08.html#adce8a98ccdfabf44d2e52700976c42e0", null ],
    [ "showsHelp", "category_c_p_alert_07_c_p_synthesized_accessors_08.html#a57e0bc1b7f1c3bf85f87879b57cf9e87", null ],
    [ "showsSuppressionButton", "category_c_p_alert_07_c_p_synthesized_accessors_08.html#ad9092841e4292d81a900816a6f099fed", null ],
    [ "suppressionButton", "category_c_p_alert_07_c_p_synthesized_accessors_08.html#ab24e8bc03ee2974878d676c5a623013f", null ],
    [ "themeView", "category_c_p_alert_07_c_p_synthesized_accessors_08.html#ab05a2b993a0ff44faa3f4d0b3f3304d3", null ],
    [ "title", "category_c_p_alert_07_c_p_synthesized_accessors_08.html#a209a4fc4be0de0e114d6a52e08bdc066", null ],
    [ "window", "category_c_p_alert_07_c_p_synthesized_accessors_08.html#a0b68186828602a5059f14c4d19c9f9df", null ]
];
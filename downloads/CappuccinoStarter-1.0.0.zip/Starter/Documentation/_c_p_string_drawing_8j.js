var _c_p_string_drawing_8j =
[
    [ "CPStringSizeCachingEnabled", "_c_p_string_drawing_8j.html#a980ebf71c842e3bd26dc6bac0f10a6e5", null ],
    [ "CPStringSizeMeasuringContext", "_c_p_string_drawing_8j.html#a0f22d3fdb6b73099b313b0419f65c35d", null ],
    [ "CPStringSizeWithFontHeightCache", "_c_p_string_drawing_8j.html#ab28d5053d20db8cc96e4cbf94d953b17", null ],
    [ "CPStringSizeWithFontInWidthCache", "_c_p_string_drawing_8j.html#a1aa7d0f9c25df87746916227626cdc76", null ]
];
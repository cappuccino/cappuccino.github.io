var _c_p_object_controller_8j =
[
    [ "CPManagedProxyEntityNameKey", "_c_p_object_controller_8j.html#afa57b9cf4f53b19ab22f2d6fd6690f5d", null ],
    [ "CPManagedProxyFetchPredicateKey", "_c_p_object_controller_8j.html#aab8b0f3249d16be23d88ab601df73c9f", null ],
    [ "CPObjectControllerAutomaticallyPreparesContentKey", "_c_p_object_controller_8j.html#acc9d44270577ec56da865221a5e3173c", null ],
    [ "CPObjectControllerContentKey", "_c_p_object_controller_8j.html#a00c47635c2857802972185849f2905ab", null ],
    [ "CPObjectControllerIsEditableKey", "_c_p_object_controller_8j.html#a6991980194cb5636040000312f8fca83", null ],
    [ "CPObjectControllerIsUsingManagedProxyKey", "_c_p_object_controller_8j.html#a8400804114d6f638957a9f3193bfcc50", null ],
    [ "CPObjectControllerManagedProxyKey", "_c_p_object_controller_8j.html#ae8c32b5e3e0eb9645078a3c9de7c2f08", null ],
    [ "CPObjectControllerObjectClassNameKey", "_c_p_object_controller_8j.html#a3300399ebfa5d2d5fceb357088dc56c9", null ],
    [ "CPObjectControllerUsesLazyFetchingKey", "_c_p_object_controller_8j.html#ae52f5cbee30716d38e3d2681f1e4c279", null ]
];
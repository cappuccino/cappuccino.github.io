var class_c_p_multiple_value_and_binding =
[
    [ "init", "class_c_p_multiple_value_and_binding.html#aa24d6c12082f9847f738377810e51fc1", null ]
];
var protocol_c_p_decimal_number_behaviors_p =
[
    [ "exceptionDuringOperation:error:leftOperand:rightOperand:", "protocol_c_p_decimal_number_behaviors-p.html#a14675e4c90d46d1fbaaa3bcd17cac28a", null ],
    [ "roundingMode", "protocol_c_p_decimal_number_behaviors-p.html#aed73ef99d0b1b8674bbe58a9a5f2a99f", null ],
    [ "scale", "protocol_c_p_decimal_number_behaviors-p.html#ad639737aa2a05c40e348813113bb23e3", null ]
];
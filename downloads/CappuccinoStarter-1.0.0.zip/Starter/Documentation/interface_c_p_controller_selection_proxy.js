var interface_c_p_controller_selection_proxy =
[
    [ "addObserver:forKeyPath:options:context:", "interface_c_p_controller_selection_proxy.html#abbfa7b43eb1b8fe82fc700a4f71bab64", null ],
    [ "controllerDidChange", "interface_c_p_controller_selection_proxy.html#ac6f66cefab5edfeccccab1d02b0796b1", null ],
    [ "controllerWillChange", "interface_c_p_controller_selection_proxy.html#ae7c26220ad14def19d72f770e1b3ad32", null ],
    [ "count", "interface_c_p_controller_selection_proxy.html#ad9ee66796dd66878702a8241d1c052b1", null ],
    [ "initWithController:", "interface_c_p_controller_selection_proxy.html#ad0d0d06977345344a1038538c1ee354a", null ],
    [ "keyEnumerator", "interface_c_p_controller_selection_proxy.html#ad9f652adc0b792acabc49b2b756775bd", null ],
    [ "observeValueForKeyPath:ofObject:change:context:", "interface_c_p_controller_selection_proxy.html#a436fe7cc7f9c3658e1bbe28926e9ed20", null ],
    [ "removeObserver:forKeyPath:", "interface_c_p_controller_selection_proxy.html#ad86da08a1fcd9fab66476e7b4a4daa13", null ],
    [ "setValue:forKey:", "interface_c_p_controller_selection_proxy.html#a52846609a7783abfaca7a910add25fe0", null ],
    [ "setValue:forKeyPath:", "interface_c_p_controller_selection_proxy.html#ab831e065859388b86f21d0c32406457e", null ],
    [ "valueForKey:", "interface_c_p_controller_selection_proxy.html#ae634870bf5600493522c303173ca0d15", null ],
    [ "valueForKeyPath:", "interface_c_p_controller_selection_proxy.html#a4da11cecb54bd60c7e4a6b0d7e689b68", null ]
];
var dir_55e1a292cb428e6e49f00848c550660e =
[
    [ "CPArray.h", "_app_kit_8doc_2_c_p_text_view_2_c_p_array_8h.html", null ],
    [ "CPFontDescriptor.h", "_c_p_font_descriptor_8h.html", null ],
    [ "CPFontDescriptor.j", "_c_p_font_descriptor_8j.html", "_c_p_font_descriptor_8j" ],
    [ "CPFontPanel.h", "_c_p_font_panel_8h.html", null ],
    [ "CPFontPanel.j", "_c_p_font_panel_8j.html", "_c_p_font_panel_8j" ],
    [ "CPLayoutManager.h", "_c_p_layout_manager_8h.html", null ],
    [ "CPLayoutManager.j", "_c_p_layout_manager_8j.html", "_c_p_layout_manager_8j" ],
    [ "CPParagraphStyle.h", "_c_p_paragraph_style_8h.html", [
      [ "CPParagraphStyle", "interface_c_p_paragraph_style.html", "interface_c_p_paragraph_style" ]
    ] ],
    [ "CPParagraphStyle.j", "_c_p_paragraph_style_8j.html", "_c_p_paragraph_style_8j" ],
    [ "CPSimpleTypesetter.h", "_c_p_simple_typesetter_8h.html", [
      [ "CPSimpleTypesetter", "interface_c_p_simple_typesetter.html", "interface_c_p_simple_typesetter" ]
    ] ],
    [ "CPTextContainer.h", "_c_p_text_container_8h.html", null ],
    [ "CPTextContainer.j", "_c_p_text_container_8j.html", "_c_p_text_container_8j" ],
    [ "CPTextStorage.h", "_c_p_text_storage_8h.html", null ],
    [ "CPTextStorage.j", "_c_p_text_storage_8j.html", "_c_p_text_storage_8j" ],
    [ "CPTextTab.h", "_c_p_text_tab_8h.html", [
      [ "CPTextTab", "class_c_p_text_tab.html", "class_c_p_text_tab" ]
    ] ],
    [ "CPTextView.h", "_c_p_text_view_8h.html", null ],
    [ "CPTextView.j", "_c_p_text_view_8j.html", "_c_p_text_view_8j" ],
    [ "CPTypesetter.h", "_c_p_typesetter_8h.html", [
      [ "CPTypesetter", "interface_c_p_typesetter.html", "interface_c_p_typesetter" ]
    ] ],
    [ "CPTypesetter.j", "_c_p_typesetter_8j.html", "_c_p_typesetter_8j" ]
];
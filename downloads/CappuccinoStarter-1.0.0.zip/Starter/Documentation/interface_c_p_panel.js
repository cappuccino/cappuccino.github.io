var interface_c_p_panel =
[
    [ "becomesKeyOnlyIfNeeded", "interface_c_p_panel.html#a6a73a5ef1356826dca2e8749169256f6", null ],
    [ "canBecomeKeyWindow", "interface_c_p_panel.html#a95db4fa3b27325974875d99e1f4ea3cf", null ],
    [ "canBecomeMainWindow", "interface_c_p_panel.html#a7cdd95663938357f332cada9308a9ddd", null ],
    [ "cancel:", "interface_c_p_panel.html#a75035cff530422cf50a030392f491c09", null ],
    [ "cancelOperation:", "interface_c_p_panel.html#a2ca155e019bc46d0c1136c71cbd52139", null ],
    [ "isFloatingPanel", "interface_c_p_panel.html#a8e6b1b3034fa22ab9daddbf940c0ef76", null ],
    [ "setBecomesKeyOnlyIfNeeded:", "interface_c_p_panel.html#a48f29fd997ead765ddd449494b84cd64", null ],
    [ "setFloatingPanel:", "interface_c_p_panel.html#a720073b07c107e8910035c1579192f08", null ],
    [ "setWorksWhenModal:", "interface_c_p_panel.html#aefebec1a1063ce94b8e234541069383f", null ],
    [ "worksWhenModal", "interface_c_p_panel.html#a7dc7f2ab9f4ba2f7b0204513595504a4", null ]
];
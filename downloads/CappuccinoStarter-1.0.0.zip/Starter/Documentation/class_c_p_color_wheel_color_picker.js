var class_c_p_color_wheel_color_picker =
[
    [ "brightnessSliderDidChange:", "class_c_p_color_wheel_color_picker.html#aed95d9fc7ff6528a1686aa479d28b7b8", null ],
    [ "colorWheelDidChange:", "class_c_p_color_wheel_color_picker.html#a9fb20387b47f5efb2cb5e14a43f7650f", null ],
    [ "currentMode", "class_c_p_color_wheel_color_picker.html#a8c27004273888de6902c7118b630a8c0", null ],
    [ "initView", "class_c_p_color_wheel_color_picker.html#aa5a9d7443871cac90c41762be0af4fda", null ],
    [ "initWithPickerMask:colorPanel:", "class_c_p_color_wheel_color_picker.html#a85a1f1123c08299bad39e9eebb9e71bf", null ],
    [ "provideNewAlternateButtonImage", "class_c_p_color_wheel_color_picker.html#a3ba104e3af2f65807009c3b1b4e7bd12", null ],
    [ "provideNewButtonImage", "class_c_p_color_wheel_color_picker.html#a53cffdff0ce505e7b87191fc460bb078", null ],
    [ "provideNewView:", "class_c_p_color_wheel_color_picker.html#a3443819ab636cea41e9028238fa616b2", null ],
    [ "setColor:", "class_c_p_color_wheel_color_picker.html#a854af280b75f4957871d648b24d32fee", null ],
    [ "supportsMode:", "class_c_p_color_wheel_color_picker.html#aa9983e219af891ad64190d41850b8239", null ],
    [ "updateColor", "class_c_p_color_wheel_color_picker.html#aa61439f8a8d6384aa871c547575693fc", null ]
];
var category_c_p_text_storage_07_c_p_synthesized_accessors_08 =
[
    [ "changeInLength", "category_c_p_text_storage_07_c_p_synthesized_accessors_08.html#a8182177d078e3e37401808ec9f53b485", null ],
    [ "editedMask", "category_c_p_text_storage_07_c_p_synthesized_accessors_08.html#a8cb2a4360a2dc1bca6ee9c54ea85a586", null ],
    [ "editedRange", "category_c_p_text_storage_07_c_p_synthesized_accessors_08.html#ae683ceacbfbe738b63b66a604482476e", null ],
    [ "font", "category_c_p_text_storage_07_c_p_synthesized_accessors_08.html#aa94ce2da2190b05c6aff2bfd7e647faa", null ],
    [ "foregroundColor", "category_c_p_text_storage_07_c_p_synthesized_accessors_08.html#ad87e3471900d65a5c648e0454b0bc076", null ],
    [ "layoutManagers", "category_c_p_text_storage_07_c_p_synthesized_accessors_08.html#a3f32d30c5e53f15781b50285126805d1", null ],
    [ "setChangeInLength:", "category_c_p_text_storage_07_c_p_synthesized_accessors_08.html#a2155c6ef45851f266b11907d09f14007", null ],
    [ "setEditedMask:", "category_c_p_text_storage_07_c_p_synthesized_accessors_08.html#a18bcf266d0b01d0b7c277ba3cef2a5fb", null ],
    [ "setFont:", "category_c_p_text_storage_07_c_p_synthesized_accessors_08.html#a41b07252360ae8368425444b8aab186c", null ],
    [ "setForegroundColor:", "category_c_p_text_storage_07_c_p_synthesized_accessors_08.html#a2e386e0a3840636544baa1d75306bcea", null ]
];
var category_c_p_u_r_l_07_c_p_coding_08 =
[
    [ "encodeWithCoder:", "category_c_p_u_r_l_07_c_p_coding_08.html#aab8c9b94f6a6627b406d9d5c036fcb78", null ],
    [ "initWithCoder:", "category_c_p_u_r_l_07_c_p_coding_08.html#a2a039dbe7920789f301fcfee721f9f1d", null ]
];
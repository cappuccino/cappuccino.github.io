var category_c_p_number_07_c_p_coding_08 =
[
    [ "encodeWithCoder:", "category_c_p_number_07_c_p_coding_08.html#a00124d6e7b9894594663fbe31a42b2e4", null ],
    [ "initWithCoder:", "category_c_p_number_07_c_p_coding_08.html#a556c33e866ec4382bb41ff21a667ae4c", null ]
];
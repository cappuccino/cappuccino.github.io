var category_c_p_user_defaults_controller_07_c_p_synthesized_accessors_08 =
[
    [ "appliesImmediately", "category_c_p_user_defaults_controller_07_c_p_synthesized_accessors_08.html#a287d6f37b89ae3d6ca6e21453e5dd900", null ],
    [ "defaults", "category_c_p_user_defaults_controller_07_c_p_synthesized_accessors_08.html#a92145064a691564c525ef66bb2ed40bd", null ],
    [ "initialValues", "category_c_p_user_defaults_controller_07_c_p_synthesized_accessors_08.html#a45c1cc2a9ec74182bf35f81f1fab9c26", null ],
    [ "setAppliesImmediately:", "category_c_p_user_defaults_controller_07_c_p_synthesized_accessors_08.html#ab4b3a9c155fdc1aa0c1043614565670d", null ],
    [ "setInitialValues:", "category_c_p_user_defaults_controller_07_c_p_synthesized_accessors_08.html#ac48454e3ef83fbc82a81c109fd113802", null ]
];
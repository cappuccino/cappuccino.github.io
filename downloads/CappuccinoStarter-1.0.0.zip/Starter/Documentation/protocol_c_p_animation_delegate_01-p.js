var protocol_c_p_animation_delegate_01_p =
[
    [ "animation:valueForProgress:", "protocol_c_p_animation_delegate_01-p.html#aa816959661e036a59d2cca6777878895", null ],
    [ "animationDidEnd:", "protocol_c_p_animation_delegate_01-p.html#abd7111f281694c6b098c485aa275968e", null ],
    [ "animationDidStop:", "protocol_c_p_animation_delegate_01-p.html#aed26bed0a182d9ee9cead90e9c7f3d6b", null ],
    [ "animationShouldStart:", "protocol_c_p_animation_delegate_01-p.html#a1b2c2a1ee2d40f71e9cd580bf027bc16", null ]
];
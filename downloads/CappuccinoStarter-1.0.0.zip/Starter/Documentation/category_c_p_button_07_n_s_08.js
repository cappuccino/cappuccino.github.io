var category_c_p_button_07_n_s_08 =
[
    [ "bezelStyle", "category_c_p_button_07_n_s_08.html#abbb88879f83a43fdce8cfc910b1fbc05", null ],
    [ "setBezelStyle:", "category_c_p_button_07_n_s_08.html#a091e705feb6e8d8b4b4b081a46a0dc3a", null ]
];
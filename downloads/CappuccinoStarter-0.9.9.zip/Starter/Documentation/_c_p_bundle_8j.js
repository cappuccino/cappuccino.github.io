var _c_p_bundle_8j =
[
    [ "<CPBundleDelegate>", "protocol_c_p_bundle_delegate-p.html", "protocol_c_p_bundle_delegate-p" ],
    [ "CPCopyLocalizedStringFromTableInBundle", "_c_p_bundle_8j.html#a7ff90366c8ed05108950030a38d78bfb", null ],
    [ "CPLocalizedString", "_c_p_bundle_8j.html#ab0c3982c540e80375722779b28365f1c", null ],
    [ "CPLocalizedStringFromTable", "_c_p_bundle_8j.html#a508528f9378101f2488816ec0d0e619f", null ],
    [ "CPBundleDidLoadNotification", "_c_p_bundle_8j.html#a6ae79b0097ef188578704caf7113c010", null ],
    [ "CPBundlesForURLStrings", "group__foundation.html#gacf1f8fc528aa85c020665fcbe609398b", null ]
];
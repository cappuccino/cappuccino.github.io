var _c_p_document_8j =
[
    [ "CPAutosaveOperation", "_c_p_document_8j.html#a7fc18a055c4cb27200e3dcd8fcb477ec", null ],
    [ "CPChangeAutosaved", "_c_p_document_8j.html#ae1b0842ca579b2d31efb96ba493108af", null ],
    [ "CPChangeCleared", "_c_p_document_8j.html#ad7ffb85d42597034df7dfac2db6b0dd7", null ],
    [ "CPChangeDone", "_c_p_document_8j.html#a21671c94fdf546117f5e3ec92a0c5f39", null ],
    [ "CPChangeReadOtherContents", "_c_p_document_8j.html#ab5bbac80b3b9e5c30852150a6b349f66", null ],
    [ "CPChangeUndone", "_c_p_document_8j.html#a21f8c9ee825321609cdaf98015428176", null ],
    [ "CPDocumentDidFailToSaveNotification", "_c_p_document_8j.html#a1667f8ea158f459534d220bc074d9e62", null ],
    [ "CPDocumentDidSaveNotification", "_c_p_document_8j.html#a88f852b071abc7065e71812411928370", null ],
    [ "CPDocumentUntitledCount", "_c_p_document_8j.html#a789a7259423582e3143faf62dd7eff00", null ],
    [ "CPDocumentWillSaveNotification", "_c_p_document_8j.html#ad7e7571f72037ca3293e049ec30e6390", null ],
    [ "CPSaveAsOperation", "_c_p_document_8j.html#aa8ca30e2b912e6263c264fe8c0338d27", null ],
    [ "CPSaveOperation", "_c_p_document_8j.html#a380314e8c2bbe71dcf5826e3b81e8bf0", null ],
    [ "CPSaveToOperation", "_c_p_document_8j.html#ab17110d00c3e4f14c59ed64d59a9e105", null ]
];
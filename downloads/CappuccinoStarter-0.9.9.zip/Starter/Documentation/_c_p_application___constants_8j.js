var _c_p_application___constants_8j =
[
    [ "CPTerminateNow", "_c_p_application___constants_8j.html#a1c76febee415ee4aa1eb9c843452c061", null ],
    [ "CPApp", "_c_p_application___constants_8j.html#a428912231c07effc32c420ee523bf0b7", null ],
    [ "CPApplicationDidBecomeActiveNotification", "_c_p_application___constants_8j.html#a32f8bcec351622bcd170d032f1c7fba7", null ],
    [ "CPApplicationDidChangeScreenParametersNotification", "_c_p_application___constants_8j.html#a3da55fd3bc10a48ca3ee3e6712066a82", null ],
    [ "CPApplicationDidFinishLaunchingNotification", "_c_p_application___constants_8j.html#aac67b83e933ef220d75f0ff0f856663a", null ],
    [ "CPApplicationDidResignActiveNotification", "_c_p_application___constants_8j.html#aac4dcacf4e92bf54a58a9fe5715dd036", null ],
    [ "CPApplicationWillBecomeActiveNotification", "_c_p_application___constants_8j.html#ae2c19826e6d5cd23a7507ef8d6f436b3", null ],
    [ "CPApplicationWillFinishLaunchingNotification", "_c_p_application___constants_8j.html#ac63a75ba8e39ab15537773fabd347bce", null ],
    [ "CPApplicationWillResignActiveNotification", "_c_p_application___constants_8j.html#aa4249c2e79a3e6d492c5b59cbf3085a1", null ],
    [ "CPApplicationWillTerminateNotification", "_c_p_application___constants_8j.html#a041956f2d6674fc3a0d267a579ea8fbd", null ],
    [ "CPRunAbortedResponse", "_c_p_application___constants_8j.html#a92f1cd3c0286309619949d073384d2fe", null ],
    [ "CPRunContinuesResponse", "_c_p_application___constants_8j.html#a26c5f833094fa3e4f82261f5e2ad4bff", null ],
    [ "CPRunStoppedResponse", "_c_p_application___constants_8j.html#aa01509a2e282606b2008e0aac6cb4065", null ],
    [ "CPTerminateCancel", "_c_p_application___constants_8j.html#aa7f5c38748ea5a451ad464552ae873cf", null ],
    [ "CPTerminateLater", "_c_p_application___constants_8j.html#adcb66381834174fe992c5b6372cae06c", null ]
];
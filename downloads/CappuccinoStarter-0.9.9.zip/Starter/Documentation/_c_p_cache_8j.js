var _c_p_cache_8j =
[
    [ "<CPCacheDelegate>", "protocol_c_p_cache_delegate-p.html", "protocol_c_p_cache_delegate-p" ],
    [ "CPCacheDelegate_cache_willEvictObject_", "_c_p_cache_8j.html#aa59fad03f49d3c30db7f586352d2b1ca", null ]
];
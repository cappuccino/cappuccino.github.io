var _c_p_appearance_8j =
[
    [ "<CPAppearanceCustomization >", "protocol_c_p_appearance_customization_01-p.html", "protocol_c_p_appearance_customization_01-p" ],
    [ "CPAppearanceNameAqua", "_c_p_appearance_8j.html#a975489ae9b31bd0d7bf73b7064b61190", null ],
    [ "CPAppearanceNameLightContent", "_c_p_appearance_8j.html#a1bb68b549d336d0e207293d1bb353d16", null ],
    [ "CPAppearanceNameVibrantDark", "_c_p_appearance_8j.html#acbf94c6cffe79b6ee797320896b2510e", null ],
    [ "CPAppearanceNameVibrantLight", "_c_p_appearance_8j.html#a03d9c15cda3fa370aa1dce40af231dd9", null ],
    [ "CPThemeStateAppearanceAqua", "_c_p_appearance_8j.html#a41b5f4b37baab84ff889f70e0a265f54", null ],
    [ "CPThemeStateAppearanceLightContent", "_c_p_appearance_8j.html#af5219cf6800480684caa382c17bba0f2", null ],
    [ "CPThemeStateAppearanceVibrantDark", "_c_p_appearance_8j.html#aba03b5d1510691f69e6cad33ef8cec4e", null ],
    [ "CPThemeStateAppearanceVibrantLight", "_c_p_appearance_8j.html#a6e7371fd8a42958b1e183a4918f29e4b", null ]
];
var _c_g_context_text_8j =
[
    [ "CGContextGetFont", "_c_g_context_text_8j.html#af89285e36b61a9c0bb9cbfa5c48c058a", null ],
    [ "CGContextGetTextMatrix", "_c_g_context_text_8j.html#ac0bc24f1cd6cdada352ca26df2074118", null ],
    [ "CGContextGetTextPosition", "_c_g_context_text_8j.html#a5612c5a3a14f71f52ceb8d61b05d4fcb", null ],
    [ "CGContextSelectFont", "_c_g_context_text_8j.html#a65b7e396190dcd1131ced71a40f1aa8a", null ],
    [ "CGContextSetTextDrawingMode", "_c_g_context_text_8j.html#afe105a06ca3b48795a9709681a794e44", null ],
    [ "CGContextSetTextMatrix", "_c_g_context_text_8j.html#ae9ee4f46312f6baaa14d21a85b2e1c52", null ],
    [ "CGContextSetTextPosition", "_c_g_context_text_8j.html#a1cd035b2a32d928d9f84135ca97a2b38", null ],
    [ "CGContextShowText", "_c_g_context_text_8j.html#a5a7c8cccbaddded32d3c79a2bc5fe7a7", null ],
    [ "CGContextShowTextAtPoint", "_c_g_context_text_8j.html#abc7c4dce2d82df4f73a97ef21f8fef2b", null ],
    [ "kCGTextFill", "_c_g_context_text_8j.html#a93ffedd887a3d622fd0224ef84334f48", null ],
    [ "kCGTextFillStroke", "_c_g_context_text_8j.html#aed29a16e8aa6113cfae6abbd741c1d63", null ],
    [ "kCGTextInvisible", "_c_g_context_text_8j.html#a2d3dba078e1ee55489ea66896313851f", null ],
    [ "kCGTextStroke", "_c_g_context_text_8j.html#a13a95ae987b7037563f73e0810b87ee4", null ]
];
var _c_p_font_descriptor_8j =
[
    [ "CPFontBoldTrait", "_c_p_font_descriptor_8j.html#a6cc97bf71fe5b3b21d7f8cc7c5d0bac0", null ],
    [ "CPFontClarendonSerifsClass", "_c_p_font_descriptor_8j.html#ac56e1fe2eaa2909c926d94b16b93d92a", null ],
    [ "CPFontCondensedTrait", "_c_p_font_descriptor_8j.html#a3de2d15d99a67e80c9cf7f52f566823a", null ],
    [ "CPFontDescriptorAttributesKey", "_c_p_font_descriptor_8j.html#a78d37df43d23ef2002c79a693752d3a7", null ],
    [ "CPFontExpandedTrait", "_c_p_font_descriptor_8j.html#af3ed4e9232f9ca686fa1eca9d7fa49a3", null ],
    [ "CPFontFamilyClassMask", "_c_p_font_descriptor_8j.html#aa285f62e10b9283cf1708e0d6a9de79f", null ],
    [ "CPFontFreeformSerifsClass", "_c_p_font_descriptor_8j.html#ab32ef2ca16f1fd6757b04101ba60f19d", null ],
    [ "CPFontItalicTrait", "_c_p_font_descriptor_8j.html#ad923add184256074bb4be272563a34a7", null ],
    [ "CPFontModernSerifsClass", "_c_p_font_descriptor_8j.html#ab6e9aaf5dae0c6af237f7e6f279efc21", null ],
    [ "CPFontNameAttribute", "_c_p_font_descriptor_8j.html#ad4942837c7940d9adb863f0a7012723c", null ],
    [ "CPFontOldStyleSerifsClass", "_c_p_font_descriptor_8j.html#a3148704ebfbc01ff671f3bd4d56a4546", null ],
    [ "CPFontSansSerifClass", "_c_p_font_descriptor_8j.html#ac8cbb994d34cf16917319ff8c83fd2e5", null ],
    [ "CPFontSerifClass", "_c_p_font_descriptor_8j.html#aac2e0939697b78d35232cdeebea073cc", null ],
    [ "CPFontSizeAttribute", "_c_p_font_descriptor_8j.html#a93683a9a32a912d6e10d9006e4bbde16", null ],
    [ "CPFontSlabSerifsClass", "_c_p_font_descriptor_8j.html#ae27e1cd9da10ab54faceb807d0ca1517", null ],
    [ "CPFontSmallCapsTrait", "_c_p_font_descriptor_8j.html#ae7094d27cfb5d3fe2de676a859feddd1", null ],
    [ "CPFontSymbolicTrait", "_c_p_font_descriptor_8j.html#a4b77f62d9b1839204c3e6b38260c4fbe", null ],
    [ "CPFontTraitsAttribute", "_c_p_font_descriptor_8j.html#aa575c594f4af60e4b0d5d4368fcb0d30", null ],
    [ "CPFontTransitionalSerifsClass", "_c_p_font_descriptor_8j.html#a25dce36b66de7e02a016b7b1b2ce6dc8", null ],
    [ "CPFontUnknownClass", "_c_p_font_descriptor_8j.html#ac7efa8022edc8f19f420bf5362fd3a40", null ],
    [ "CPFontWeightTrait", "_c_p_font_descriptor_8j.html#a83aaf7b201c300df46da1bcb14497d79", null ]
];
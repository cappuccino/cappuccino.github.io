var _c_p_font_panel_8j =
[
    [ "kBackgroundColorChanged", "_c_p_font_panel_8j.html#a3e089c6e7c0d3857441c06eb38e10ef4", null ],
    [ "kBorderSpacing", "_c_p_font_panel_8j.html#a71965816b24b010e243a78766e2bef9b", null ],
    [ "kFontNameChanged", "_c_p_font_panel_8j.html#acf7de2989c162ecde1c4a63a756c9734", null ],
    [ "kInnerSpacing", "_c_p_font_panel_8j.html#a179e9edaebe64a85bae6b891e2a71511", null ],
    [ "kNothingChanged", "_c_p_font_panel_8j.html#a0453e1eba7c53556a4478076da4e7927", null ],
    [ "kSizeChanged", "_c_p_font_panel_8j.html#a97b88ba0be510e932c9bcd3179329e14", null ],
    [ "kTextColorChanged", "_c_p_font_panel_8j.html#a4ff661bfcc240aa08834e1a64e9be246", null ],
    [ "kToolbarHeight", "_c_p_font_panel_8j.html#a9df5b27b86b7eb83a84b597de862da4d", null ],
    [ "kTypefaceChanged", "_c_p_font_panel_8j.html#abdcf9e7ed2e9786893f8e98410d48a1c", null ],
    [ "kTypefaceIndex_Bold", "_c_p_font_panel_8j.html#a7149c92d5e71416a393629c355c0496e", null ],
    [ "kTypefaceIndex_BoldItalic", "_c_p_font_panel_8j.html#a0e2cfaf952ef7f2c9b29c97d8aa5fa0b", null ],
    [ "kTypefaceIndex_Italic", "_c_p_font_panel_8j.html#a91b8777cb4018304536aa5f6d790aedc", null ],
    [ "kTypefaceIndex_Normal", "_c_p_font_panel_8j.html#a6ee251357d33e4ef587028c64bef4be2", null ],
    [ "kUnderlineChanged", "_c_p_font_panel_8j.html#aa390e3532a5f56e6df04e2922b790300", null ],
    [ "kWeightChanged", "_c_p_font_panel_8j.html#a4bfbb25cf7acf4af77d5a005abe5f8c4", null ]
];
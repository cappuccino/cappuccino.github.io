exports.testXHR = require("./xhr-tests.js");

require("test/runner").run(exports);

(function (global, evalGlobal) {

alert(global + " " + evalGlobal);
    var debug = false; /*TODO*/ // boolean

    var read = function (path) {
        var file = Titanium.Filesystem.getFile(path);
alert(file.nativePath());
        if (!file.isFile())
            throw new Error(path + ' does not exist.');

        var stream = Titanium.Filesystem.getFileStream(path);
        try {
            stream.open();
            var result = stream.read();

            return result;

        } finally {
            stream.close();
        }
    };

    var isFile = function (path) {
        try { return Titanium.Filesystem.getFile(path).isFile(); } catch (e) {}
        return false;
    };

    var prefix = "";
    if (typeof NARWHAL_HOME !== "undefined") {
        prefix = NARWHAL_HOME;
        delete NARWHAL_HOME;
    } else {
        prefix = Titanium.Process.getEnv("NARWHAL_HOME", Titanium.Filesystem.getResourcesDirectory() + '/narwhal');//"");
    }

    var path = "";
    if (typeof NARWHAL_PATH !== "undefined") {
        path = NARWHAL_PATH;
        delete NARWHAL_PATH;
    } else {
        path = Titanium.Process.getEnv("NARWHAL_PATH", "");
        if (!path)
            path = [prefix + "/platforms/titanium/lib", prefix + "/platforms/default/lib", prefix + "/lib"].join(":");
    }

    eval(read(prefix + "/narwhal.js"))({
        global: global,
        evalGlobal: evalGlobal,
        platform: 'titanium',
        platforms: ['titanium', 'default'],
        debug: debug,
        print: print,
        evaluate: function (text) {
            // or something better here:
            return eval(
                "(function(require,exports,system,print){" +
                text +
                "/**/\n})"
            );
        },
        read: read,
        isFile: isFile,
        prefix: prefix,
        path: path
    });

})(this, function () {
    return eval(arguments[0]);
});

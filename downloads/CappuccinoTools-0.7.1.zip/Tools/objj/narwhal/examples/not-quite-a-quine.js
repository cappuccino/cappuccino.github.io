system.stdout.write(system.fs.read(module.path)).flush();

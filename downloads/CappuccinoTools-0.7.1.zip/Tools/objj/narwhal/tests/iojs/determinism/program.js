var test = require('test');
require('submodule/a');
print('DONE', 'info');

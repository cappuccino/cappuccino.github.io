var _c_p_menu_8j =
[
    [ "CPMenuAutoEnablesItemsKey", "_c_p_menu_8j.html#a328b5f0d835720b32a1d736d763a6dd5", null ],
    [ "CPMenuDidAddItemNotification", "_c_p_menu_8j.html#a32bf606de8541d2c2471963194b288a5", null ],
    [ "CPMenuDidChangeItemNotification", "_c_p_menu_8j.html#aa075a249864c177e5a919183a8bab841", null ],
    [ "CPMenuDidEndTrackingNotification", "_c_p_menu_8j.html#a5d1b586a4123ba5565d1c9e747e1eebd", null ],
    [ "CPMenuDidRemoveItemNotification", "_c_p_menu_8j.html#aca917d3d8987208a40a4f908fbf566ff", null ],
    [ "CPMenuItemsKey", "_c_p_menu_8j.html#af01d9249fe5f0decaf3442c6ccf3ff86", null ],
    [ "CPMenuNameKey", "_c_p_menu_8j.html#aa3074c0a00783b8bd20b60d46af46df4", null ],
    [ "CPMenuShowsStateColumnKey", "_c_p_menu_8j.html#a5b9a10cc1ba024968775d7c1dc19236e", null ],
    [ "CPMenuTitleKey", "_c_p_menu_8j.html#a420c32d01d3b5b86a8c00217158b28f8", null ]
];
var _c_a_layer_8j =
[
    [ "ADJUST_CONTENTS_ZINDEX", "_c_a_layer_8j.html#a15cb1b6757121dfb227d46b0ce0f963f", null ],
    [ "DOM", "_c_a_layer_8j.html#aac46d63213c27c242670119b099448c4", null ],
    [ "CALayerCompositeUpdateMask", "_c_a_layer_8j.html#a0d8d5fbf9708caaee8b1b1147e7ed988", null ],
    [ "CALayerDisplayUpdateMask", "_c_a_layer_8j.html#aea3fa0c520450b903260bc7d7d91e873", null ],
    [ "CALayerDOMUpdateMask", "_c_a_layer_8j.html#a13368e69c48203d60d0e8eba3a151791", null ],
    [ "CALayerFrameOriginUpdateMask", "_c_a_layer_8j.html#aaf1285d3b64e902c2c83bb85b7937e31", null ],
    [ "CALayerFrameSizeUpdateMask", "_c_a_layer_8j.html#a59e67f97b348d19a1eedb5fc71c97132", null ],
    [ "CALayerGeometryAffineTransformMask", "_c_a_layer_8j.html#af551f56d2ec1637a4dd3b8e6672d284e", null ],
    [ "CALayerGeometryAnchorPointMask", "_c_a_layer_8j.html#a4481f9da252746e5b81eb67af6f9d0f8", null ],
    [ "CALayerGeometryBoundsMask", "_c_a_layer_8j.html#a9d7b1c58912534373644657a8e532d5c", null ],
    [ "CALayerGeometryParentSublayerTransformMask", "_c_a_layer_8j.html#afafdb56b39f5840584dabc52cac0a9a7", null ],
    [ "CALayerGeometryPositionMask", "_c_a_layer_8j.html#ac9837ddcbab2fccd293e6c8d9a5d78b3", null ],
    [ "CALayerRegisteredRunLoopUpdates", "_c_a_layer_8j.html#aa5c21f4390935ff640bffb4758e73603", null ],
    [ "CALayerZPositionUpdateMask", "_c_a_layer_8j.html#acd4260da148e61285fdf91c10bf2e661", null ],
    [ "USE_BUFFER", "_c_a_layer_8j.html#af1278afeafe5ca978f308332072f9efd", null ]
];
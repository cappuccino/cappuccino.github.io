var _c_p_color_well_8j =
[
    [ "CPColorWellBorderedKey", "_c_p_color_well_8j.html#ad4723a2dad9ffd3ffe8f508c384f2a1c", null ],
    [ "CPColorWellColorKey", "_c_p_color_well_8j.html#a2f6a35207dcc9c16f9471f8c1c134952", null ]
];
var _c_p_error_8j =
[
    [ "CPCappuccinoErrorDomain", "_c_p_error_8j.html#acf674a62e47db5a791f7c3d3dad5bf4c", null ],
    [ "CPFilePathErrorKey", "_c_p_error_8j.html#a39ce255ef8f5a9c57440aee57cf91721", null ],
    [ "CPHelpAnchorErrorKey", "_c_p_error_8j.html#a9ec23f82c606a1acc3a0cb8fd6d45cc8", null ],
    [ "CPLocalizedDescriptionKey", "_c_p_error_8j.html#a286ca4325a9b4edfce4bb2e8d78896b6", null ],
    [ "CPLocalizedFailureReasonErrorKey", "_c_p_error_8j.html#ad2b8c21db267244f901d2a195f102faf", null ],
    [ "CPLocalizedRecoveryOptionsErrorKey", "_c_p_error_8j.html#a5e3a7584bd8ec2fd630c99bbf8325e3a", null ],
    [ "CPLocalizedRecoverySuggestionErrorKey", "_c_p_error_8j.html#ac4a73bbc254618a4b4bd683c101ac19a", null ],
    [ "CPRecoveryAttempterErrorKey", "_c_p_error_8j.html#a36de32d9dc9300fb0495600cee468ab1", null ],
    [ "CPStringEncodingErrorKey", "_c_p_error_8j.html#a0f529e3af138ed11b3067b8b14c02589", null ],
    [ "CPUnderlyingErrorKey", "_c_p_error_8j.html#a1a58d4a1edbd1d1dcea698043a2f8659", null ],
    [ "CPURLErrorKey", "_c_p_error_8j.html#a85495d9726e4d817e99ef272e44a3dd0", null ]
];